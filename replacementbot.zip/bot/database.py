import datetime

from motor.motor_asyncio import AsyncIOMotorClient

from .config import Config


class Database:
    def __init__(self) -> None:
        self.client = AsyncIOMotorClient(Config.DATABASE_URL)
        self.database = self.client["admin-chat-bot"]
        self.users = self.database["users"]
        self.tickets = self.database["tickets"]

    async def insert_user(self, user_id: int):
        await self.users.insert_one(
            {"user_id": user_id, "datetime": datetime.datetime.now()}
        )

    async def delete_user(self, user_id: int):
        await self.users.delete_one({"user_id": user_id})

    async def get_user(self, user_id: int):
        user = await self.users.find_one({"user_id": user_id})
        if not user:
            return {}
        return user

    async def insert_ticket(
        self,
        ticket_id: str,
        user_id: int,
        order_id: str,
        transaction_id: str,
        status: str,
        description: str,
    ):
        await self.tickets.insert_one(
            {
                "ticket_id": ticket_id,
                "user_id": user_id,
                "order_id": order_id,
                "transaction_id": transaction_id,
                "status": status,
                "description": description,
                "datetime": datetime.datetime.now(),
            }
        )

    async def update_ticket(self, ticket_id: str, key: str, value: str):
        await self.tickets.update_one({"ticket_id": ticket_id}, {"$set": {key: value}})

    async def delete_ticket(self, ticket_id: str):
        await self.tickets.delete_one({"ticket_id": ticket_id})

    async def get_ticket(self, ticket_id: str):
        ticket = await self.tickets.find_one({"ticket_id": ticket_id})
        if not ticket:
            return {}
        return ticket

    async def is_ticket(self, ticket_id: str) -> bool:
        ticket = await self.tickets.find_one({"ticket_id": ticket_id})
        if not ticket:
            return False
        return True


db = Database()
