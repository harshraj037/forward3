START_MSG = """
**Hello 👋,
Dear User 🤝**

- Welcome to spadone.cc telegram support bot / replacements bot 🤖.

**🛍️ If you have made a purchase on the website [ spadone.cc ] & haven’t recieved the product / have received wrong product / product isn’t working !!!
🌹 In all these cases our support will help you in solving the case and will give you replacements or refunds if possible.**

`Click The Buttons Below For Further Information ℹ️`
"""

TICKET_CLOSED = """
**Your Ticket with ID [{0}] has been closed by the admin ❌

Create new ticket if the problem isn’t solved yet by us 🎫**
"""
