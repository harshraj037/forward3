from pyrogram import filters
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, Message

from .. import app
from ..functions.forcesub import ForceSub
from . import START_MSG


@app.on_message(filters.command("start") & filters.private, group=1)
async def start(_, message: Message):
    status = await ForceSub.check_status(message.from_user.id)
    if status["joined"] == False:
        await message.reply_text("You must join the channel to use me!")
        return

    btns = [
        [InlineKeyboardButton("Create A Ticket 🎫", "create_ticket")],
        [InlineKeyboardButton("Updates 📢", "updates")],
    ]

    await message.reply_photo(
        "./assets/start.png",
        caption=START_MSG,
        reply_markup=InlineKeyboardMarkup(btns),
    )


@app.on_message(filters.command("start") & filters.group, group=2)
async def start_gc(_, message: Message):
    await message.reply_text("I am alive!")
