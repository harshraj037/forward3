from pyrogram import filters
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InputMediaPhoto,
    Message,
)

from .. import Config, app
from ..database import db
from ..functions.tools import generate_ticket_id
from . import START_MSG, TICKET_CLOSED


@app.on_callback_query(filters.regex(r"updates"))
async def updates(_, cb: CallbackQuery):
    await cb.message.edit_media(
        InputMediaPhoto("./assets/updates.png"),
        InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton("Website 💻", url="https://spadone.cc"),
                    InlineKeyboardButton("Updates 📢", url="https://t.me/spadonecc"),
                ],
                [InlineKeyboardButton("🏠 Home", "home")],
            ]
        ),
    )


@app.on_callback_query(filters.regex(r"home"))
async def home(_, cb: CallbackQuery):
    await cb.message.edit_media(
        InputMediaPhoto("./assets/start.png", START_MSG),
        InlineKeyboardMarkup(
            [
                [InlineKeyboardButton("Create A Ticket 🎫", "create_ticket")],
                [InlineKeyboardButton("Updates 📢", "updates")],
            ]
        ),
    )


@app.on_callback_query(filters.regex(r"create_ticket"))
async def create_ticket(_, cb: CallbackQuery):
    order_id: Message = await app.ask(
        cb.message.chat.id,
        "Kindly send your “ORDER ID” which was given to you after receiving the order from us.",
        filters=filters.text,
        timeout=120,
    )

    transaction_id: Message = await app.ask(
        cb.message.chat.id,
        "Kindly send the payment “TRANSACTION ID” which was given to you when you paid to us by your respective payment app.\n\n**⚠️ Note : Send web receipt if you have paid using CASHAPP.**",
        filters=filters.text,
        timeout=120,
    )

    await app.send_photo(
        cb.message.chat.id,
        "./assets/example.png",
        "Hello support,\nI am facing [ Explain Issue ] this issue with [ Product Name ] product and the total amount which i paid was [ Amount ] & i have bought [ Quantity ] from your website.\n\nProofs are given above so please solve my problem as soon as possible.",
    )

    proofs: Message = await app.ask(
        cb.message.chat.id,
        "Kindly send the description of what issue you have faced with the order with proof screenshots.\n\n**⚠️ Note : Attach the screenshot proofs with the description post as done in the example above 👆**",
        filters=filters.photo,
        timeout=120,
    )

    ticket_id = generate_ticket_id()
    while await db.is_ticket(ticket_id):
        ticket_id = generate_ticket_id()

    Config.TICKETS[ticket_id] = {
        "order_id": order_id.text,
        "transaction_id": transaction_id.text,
        "proofs": proofs,
    }

    await app.send_message(
        cb.message.chat.id,
        f"Do you confirm this ticket [#{ticket_id}] to be posted for enquiry and to get replacement?",
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton("Confirm ✅", f"confirm_ticket:{ticket_id}"),
                    InlineKeyboardButton("Cancel ❌", f"cancel_ticket:{ticket_id}"),
                ]
            ]
        ),
    )


@app.on_callback_query(filters.regex(r"confirm_ticket"))
async def confirm_ticket(_, cb: CallbackQuery):
    ticket_id: str = str(cb.data.split(":")[1])
    ticket: dict = Config.TICKETS.get(ticket_id)
    if not ticket:
        return await cb.answer(
            "This ticket is already confirmed or cancelled or expired. Please create a new one.",
            show_alert=True,
        )

    proofs: Message = ticket.get("proofs")
    await db.insert_ticket(
        ticket_id,
        cb.message.chat.id,
        ticket["order_id"],
        ticket["transaction_id"],
        "pending",
        proofs.caption or "No description provided.",
    )

    _msg = await proofs.forward(Config.LOGGER_ID)
    await _msg.reply_text(
        f"**🎫 New Ticket Created** - #{ticket_id}\n\n**| ~ User:** {cb.from_user.mention} \n**| ~ Username:** @{cb.from_user.username} \n**| ~ Order ID:** `{ticket['order_id']}` \n**| ~ Transaction ID:** `{ticket['transaction_id']}`",
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton("Confirm Replacement ✅", f"cnf_replace:{ticket_id}"),
                ],
                [
                    InlineKeyboardButton("Cancel Replacement ❌", f"rej_replace:{ticket_id}"),
                ],
            ]
        ),
    )

    del Config.TICKETS[ticket_id]
    await cb.message.edit_text(
        f"Your ticket [#{ticket_id}] has been successfully posted for enquiry and to get replacement. Our support team will contact you soon.",
    )


@app.on_callback_query(filters.regex(r"cancel_ticket"))
async def cancel_ticket(_, cb: CallbackQuery):
    ticket_id: str = str(cb.data.split(":")[1])
    ticket: dict = Config.TICKETS.get(ticket_id)
    if not ticket:
        return await cb.answer(
            "This ticket is already confirmed or cancelled or expired. Please create a new one.",
            show_alert=True,
        )

    del Config.TICKETS[ticket_id]
    await cb.message.edit_text(
        f"Your ticket [#{ticket_id}] has been successfully cancelled. You can create a new one if needed.",
    )


@app.on_callback_query(filters.regex(r"cnf_replace"))
async def cnf_replace(_, cb: CallbackQuery):
    ticket_id: str = str(cb.data.split(":")[1])
    ticket: dict = await db.get_ticket(ticket_id)
    if not ticket:
        return await cb.answer(
            "This ticket does not exists in the database.",
            show_alert=True,
        )

    msg_to_user: Message = await app.ask(
        cb.message.chat.id,
        f"Enter the message you want to send to the user with ticket #{ticket_id}.\n\nSend /cancel to cancel the process.",
        filters=filters.text,
        timeout=120,
    )

    if msg_to_user.text.lower() == "/cancel":
        return await cb.message.edit_text("Process cancelled!")

    await app.send_message(int(ticket['user_id']), TICKET_CLOSED.format(ticket_id))
    await app.send_message(int(ticket['user_id']), msg_to_user.text)
    await db.update_ticket(ticket_id, "status", "confirmed")
    await cb.message.edit_text(f"Replacements confirmed for ticket [#{ticket_id}] by {cb.from_user.mention}")


@app.on_callback_query(filters.regex(r"rej_replace"))
async def rej_replace(_, cb: CallbackQuery):
    ticket_id: str = str(cb.data.split(":")[1])
    ticket: dict = await db.get_ticket(ticket_id)
    if not ticket:
        return await cb.answer(
            "This ticket does not exists in the database.",
            show_alert=True,
        )

    msg_to_user: Message = await app.ask(
        cb.message.chat.id,
        f"Enter the message you want to send to the user with ticket #{ticket_id}.\n\nSend /cancel to cancel the process.",
        filters=filters.text,
        timeout=120,
    )

    if msg_to_user.text.lower() == "/cancel":
        return await cb.message.edit_text("Process cancelled!")

    await app.send_message(int(ticket['user_id']), TICKET_CLOSED.format(ticket_id))
    await app.send_message(int(ticket['user_id']), msg_to_user.text)
    await db.update_ticket(ticket_id, "status", "rejected")
    await cb.message.edit_text(f"Replacements rejected for ticket [#{ticket_id}] by {cb.from_user.mention}")
