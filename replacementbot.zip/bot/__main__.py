from pyrogram import idle

from . import app


async def main():
    await app.start()
    print("Bot started.")
    await idle()
    await app.stop()
    print("Bot stopped.")


if __name__ == "__main__":
    app.run(main())
