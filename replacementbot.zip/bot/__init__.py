import pyroaddon
from pyrogram import Client

from .config import Config

app = Client(
    "chatbot",
    Config.API_ID,
    Config.API_HASH,
    bot_token=Config.BOT_TOKEN,
    plugins=dict(root="bot.plugins"),
)
