from os import getenv

from dotenv import load_dotenv

load_dotenv()


class Config:
    API_ID = int(getenv("API_ID", 0))
    API_HASH = getenv("API_HASH")
    BOT_TOKEN = getenv("BOT_TOKEN")
    DATABASE_URL = getenv("DATABASE_URL")
    LOGGER_ID = getenv("LOGGER_ID")
    FORCE_SUB_CHANNEL = int(getenv("FORCE_SUB_CHANNEL", 0))
    TICKETS = {}
