from .. import Config, app
from pyrogram.errors import UserNotParticipant



class ForceSub:
    def __init__(self) -> None:
        pass

    @staticmethod
    async def check_status(user_id: int):
        if Config.FORCE_SUB_CHANNEL == 0:
            return {
                "joined": True,
                "message": "force sub channel is not set."
            }

        try:
            await app.get_chat_member(Config.FORCE_SUB_CHANNEL, user_id)
        except UserNotParticipant:
            return {
                "joined": False,
                "message": "user is not joined in the force sub channel."
            }
        except Exception as e:
            return {
                "joined": False,
                "message": str(e)
            }

        return {
            "joined": True,
            "message": "user is joined in the force sub channel."
        }
