## Follow these steps to deploy the bot

- Edit the sample.env and fillup every env mentioned there.
- Rename sample.env to .env
- Install requirements: `pip install -r requirements.txt`
- Start the bot: `python3 -m bot`


## ENV explained

- DATABASE_URL : MongoDB Url
- LOGGER_ID : Chat ID of the admin group where bot must be an admin.
- BOT_TOKEN : Bot token from @Botfather

